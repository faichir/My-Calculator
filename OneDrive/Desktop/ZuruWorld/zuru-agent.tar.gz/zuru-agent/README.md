# Zuru Virtual Assistant
Run locally:  npm install && cp .env.example .env && npm start   -> http://localhost:3000
Data is stored in ./data/zuru.db (SQLite). Back it up or mount it on a persistent disk when deployed.
